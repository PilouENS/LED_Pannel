/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    gpio.h
  * @brief   This file contains all the function prototypes for
  *          the gpio.c file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __GPIO_H__
#define __GPIO_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* USER CODE BEGIN Private defines */
// --- PINS DE CONTROLE ---
#define CLOCK_PIN_Pin        GPIO_PIN_9
#define CLOCK_PIN_GPIO_Port   GPIOH

#define OUTPUT_E_Pin        GPIO_PIN_11
#define OUTPUT_E_GPIO_Port    GPIOH

#define LE_PIN_Pin         GPIO_PIN_14
#define LE_PIN_GPIO_Port      GPIOH

#define SEQ_1_Pin             GPIO_PIN_5
#define SEQ_1_GPIO_Port       GPIOE

#define SEQ_2_Pin            GPIO_PIN_6
#define SEQ_2_GPIO_Port       GPIOE

// --- PINS LED ROUGES ---
#define RED1_Pin            GPIO_PIN_6
#define RED1_GPIO_Port        GPIOA

#define RED2_Pin          GPIO_PIN_4
#define RED2_GPIO_Port        GPIOA

#define RED3_Pin              GPIO_PIN_9
#define RED3_GPIO_Port        GPIOG

#define RED4_Pin              GPIO_PIN_13
#define RED4_GPIO_Port        GPIOH

/* USER CODE END Private defines */

void MX_GPIO_Init(void);

/* USER CODE BEGIN Prototypes */

/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif
#endif /*__ GPIO_H__ */

